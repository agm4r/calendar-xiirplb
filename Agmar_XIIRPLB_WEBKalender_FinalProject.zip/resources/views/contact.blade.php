@extends('master')

<!-- judul halaman -->
@section('judul halaman', 'Halaman Contact')

<!-- Isi Konten -->
@section('konten')

  <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    CALL ME
                </div>
                <div>
                    <span>089512011967</span>
                </div>
                <div>
                  <span>-</span>
                </div>
                <div>
                    <span>agmarputra@gmail.com</span>
                </div>
            </div>
        </div> 

@endsection