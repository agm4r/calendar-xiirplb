 <!-- Semua Events -->



    <h3>Semua Events</h3>

        <table border="1">
          <thead>
            <tr>
              <th>No</th>
              <th>Acara</th>
              <th>Tanggal</th>
              <th>Jam</th>
              <th>Notes</th>
              <th>Pembuat</th>
            </tr>
          </thead>
          <tbody>

            <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <th><?php echo e($i++); ?></th>
              <td><?php echo e($d->title); ?></td>
              <td><?php echo e(date('d F Y', strtotime($d->date))); ?></td>
              <td><?php echo e($d->time); ?></td>
              <td><?php echo e($d->Notes); ?></td>
              <td><?php echo e($d->name); ?></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
<?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_WEBKalender_FinalProject\resources\views/events_excel.blade.php ENDPATH**/ ?>