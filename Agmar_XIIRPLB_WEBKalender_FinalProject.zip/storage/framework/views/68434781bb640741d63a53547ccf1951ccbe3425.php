

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'Halaman Contact'); ?>

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>

  <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    CALL ME
                </div>
                <div>
                    <span>089512011967</span>
                </div>
                <div>
                  <span>-</span>
                </div>
                <div>
                    <span>agmarputra@gmail.com</span>
                </div>
            </div>
        </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_WEBKalender_FinalProject\resources\views/contact.blade.php ENDPATH**/ ?>