<style>
        .container {
            font-family: 'Noto Sans', sans-serif;
            margin-top: 10px;
        }
        h3 {
            margin-bottom: 20px;
        }
        th {
            height: 20px;
            text-align: center;
        }
        td {
            height: 20px;
        }
        .today {
            background: orange;
        }
        th:nth-of-type(1), td:nth-of-type(1) {
            color: red;
        }
        th:nth-of-type(7), td:nth-of-type(7) {
            color: blue;
        }
</style>


<?php $__env->startSection('title', 'Calendar XII RPL B'); ?>

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'Calendar XII RPL B'); ?>

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>

        <h3><a href="?ym=<?php echo e($prev); ?>">&lt;</a> <?php echo e($html_title); ?> <a href="?ym=<?php echo e($next); ?>">&gt;</a></h3>
        <div class="container"> 
            <table class="table table-bordered">
                <tr>
                    <th>S</th>
                    <th>M</th>
                    <th>T</th>
                    <th>W</th>
                    <th>T</th>
                    <th>F</th>
                    <th>S</th>
                </tr>
                  <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <?php 
                        echo $week;
                      ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <p class="float-right">Klik pada tanggal untuk menambahkan acara!</p>

        </div><br><br>

        <!-- Semua Events -->

    <h3>Semua Events</h3>
    <div class="content float-center">
        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="col">No</th>
              <th scope="col">Acara</th>
              <th scope="col">Tanggal</th>
              <th scope="col">Jam</th>
              <th scope="col">Notes</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <th scope="row" class="text-dark"><?php echo e($i++); ?></th>
              <td class="text-dark"><?php echo e($d->title); ?></td>
              <td><?php echo e(date('d F Y', strtotime($d->date))); ?></td>
              <td><?php echo e($d->time); ?></td>
              <td><?= $d->Notes ?></td>
              <td>
                 <button type="button" class="btn btn-light"><a class="text-dark" href="edit/<?php echo e($d->id); ?>/<?php echo e($d->date); ?>">Ubah</a></button>
                <button type="button" class="btn btn-dark"><a class="text-light" onclick="return confirm('Apakah anda yakin ingin mengahpus event <?php echo e($d->title); ?>')" href="delete/<?php echo e($d->id); ?>/<?php echo e(0); ?>">Hapus</a></button>
              </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
        <a class="float-right text-success" href="/export_excel" class="text-success">Export ke .xls</a>
        <center><a class="text-dark" href="/"> Kembali </a></center>
    </div>

<br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_ProjectKalender\resources\views/calendar.blade.php ENDPATH**/ ?>