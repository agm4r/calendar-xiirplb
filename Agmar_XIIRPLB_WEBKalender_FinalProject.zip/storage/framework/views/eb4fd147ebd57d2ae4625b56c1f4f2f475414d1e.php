

<?php $__env->startSection('title', 'Event XII RPL B'); ?>

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'Events Siswa'); ?>

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>


<h3>Events tanggal  <?php echo e(date("d F Y", strtotime($date))); ?></h3>

  <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Acara</th>
      <th scope="col">Jam</th>
      <th scope="col">Notes</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>

    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($d->title); ?></td>
      <td><?php echo e($d->time); ?></td>
      <td><?php echo e($d->Notes); ?></td>
      <td>
         <button type="button" class="btn btn-light">
          <a class="text-dark" href="edit/<?php echo e($d->id_event); ?>/<?php echo e($mark = 0); ?> ">Ubah</a>
        </button>
          <button type="button" class="btn btn-dark">
            <a class="text-light" onclick="return confirm('Apakah anda yakin ingin mengahpus event <?php echo e($d->title); ?>')" href="delete/<?php echo e($d->id_event); ?>/<?php echo e($d->date); ?>">Hapus</a>
          </button>
      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
<a class="text-dark" href="/events/tambah/<?php echo e($date); ?>">Tambah Events</a>

<br><br><center><a class="text-dark" href="/calendar">Back</a></center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_WEBKalender_FinalProject\resources\views/events.blade.php ENDPATH**/ ?>