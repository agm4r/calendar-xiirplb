

<?php $__env->startSection('title', 'Edit Events'); ?>

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'Edit Event'); ?>
 
<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>

  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <form action="/events/update/<?php echo e($mark); ?>" method="post">
    <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label>ID</label>
    <input type="text" class="form-control" name="id" value="<?php echo e($d->id); ?>" readonly>
  </div>
  <div class="form-group">
    <label>JUDUL</label>
    <input type="text" class="form-control" name="title" value="<?php echo e($d->title); ?>">
  </div>
  <div class="form-group">
    <label>DATE</label>
    <?php if($mark == 0): ?>
      <input type="date" class="form-control" name="date" value="<?php echo e($d->date); ?>" readonly>
    <?php else: ?>
      <input type="date" class="form-control" name="date" value="<?php echo e($d->date); ?>">
    <?php endif; ?>
  </div>
   <div class="form-group">
    <label>PUKUL</label>
   <input type="time" id="timeslot" class="form-control" name="time" value="<?php echo e($d->time); ?>" required>
  </div>
   <div class="form-group">
    <label>NOTES</label>
    <input type="text" class="form-control" name="notes" value="<?php echo e($d->Notes); ?>">
  </div>
  <button type="submit" name="submit" class="btn btn-dark">Submit</button>
</form>

<br><br><center><a class="text-dark" href="/events/<?php echo e($d->date); ?>">Back</a></center>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_ProjectKalender\resources\views/calendar/update.blade.php ENDPATH**/ ?>