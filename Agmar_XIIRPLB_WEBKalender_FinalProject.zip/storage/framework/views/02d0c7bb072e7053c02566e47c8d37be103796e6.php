

<?php $__env->startSection('title', 'Tambah Siswa XII RPL B'); ?>

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'Tambah Siswa'); ?>

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>

  <form action="/xiirplb/store" method="post">
    <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label>NISN</label>
    <input type="text" class="form-control" name="nisn" >
  </div>
  <div class="form-group">
    <label>NAMA</label>
    <input type="text" class="form-control" name="nama" >
  </div>
  <div class="form-group">
    <label>JENIS KELAMIN</label>
    <select class="form-control" name="jenis_kelamin">
      <option>Lelaki</option>
      <option>Perempuan</option>
    </select>
  </div>
  <div class="form-group">
    <label>ALAMAT</label>
    <input type="text" class="form-control" name="alamat" >
  </div>
  <!-- <div class="form-group">
    <label>PUKUL</label>
    <input type="time" id="timeslot" class="form-control" name="timeslot" placeholder="Time" required>
  </div> -->
  <button type="submit" name="submit" class="btn btn-dark">Submit</button>
</form>

<br><br><center><a class="text-dark" href="/xiirplb/siswa">Back</a></center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_agmar\resources\views/tambah.blade.php ENDPATH**/ ?>