<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.css')); ?>">


    <title>biodata Siswa</title>
  </head>
  <body>

    <div class="container valign">
        <h3>FORMULIR SISWA SMKN 4 PADALARANG</h3>
       <div class="card" style="width: 18rem;">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><?php echo e($nama); ?></li>
          <li class="list-group-item"><?php echo e($kelas); ?></li>
          <li class="list-group-item"><?php echo e($alamat); ?></li>
          <li class="list-group-item"><?php echo e($agama); ?></li>
          <li class="list-group-item"><?php echo e($tempatLahir); ?></li>
          <li class="list-group-item"><?php echo e($tglLahir); ?></li>
        </ul>
      </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\project_agmar\resources\views/biodataSiswa.blade.php ENDPATH**/ ?>