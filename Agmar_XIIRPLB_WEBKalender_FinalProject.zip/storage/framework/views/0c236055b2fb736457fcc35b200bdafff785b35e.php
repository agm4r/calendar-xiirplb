

<?php $__env->startSection('title', 'Tambah events XII RPL B'); ?>

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'XII RPL B'); ?>

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>


<h3>Tambah event <?php echo e(date('d F Y', strtotime($date))); ?></h3>

  <form action="/events/insert" method="post">
    <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label>Judul</label>
    <input type="text" class="form-control" name="title">
  </div>
  <div class="form-group">
    <label>DATE</label>
    <input type="date" class="form-control" name="date" value="<?php echo e($date); ?>" readonly>
  </div>
  <div class="form-group">
    <label>PUKUL</label>
    <input type="time" id="timeslot" class="form-control" name="time" placeholder="Time" required>
  </div>
  <div class="form-group">
    <label>NOTES</label>
    <textarea type="text" name="notes" cols="3" rows="5" class="form-control" required></textarea>  
  </div>
  <button type="submit" name="submit" class="btn btn-dark">Submit</button>
</form>


<br><br><center><a class="text-dark" href="/events/<?php echo e($date); ?>">Back</a></center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_WEBKalender_FinalProject\resources\views/calendar/tambah.blade.php ENDPATH**/ ?>