

<?php $__env->startSection('title', 'Siswa XII RPL B'); ?>

<!-- judul halaman -->
<?php $__env->startSection('judul halaman', 'Halaman XII RPL B'); ?>

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>

  <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">NISN</th>
      <th scope="col">NAMA</th>
      <th scope="col">JENIS KELAMIN</th>
      <th scope="col">ALAMAT</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>

    <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $murid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($murid->nisn); ?></th>
      <td><?php echo e($murid->nama); ?></td>
      <td><?php echo e($murid->jenis_kelamin); ?></td>
      <td><?php echo e($murid->alamat); ?></td>
      <td>
        <button type="button" class="btn btn-light"><a class="text-dark" href="update/<?php echo e($murid->nisn); ?>">Ubah</a></button>
        <button type="button" class="btn btn-dark"><a class="text-light" onclick="return confirm('Apakah anda yakin ingin mengahpus data <?php echo e($murid->nama); ?>')" href="delete/<?php echo e($murid->nisn); ?>">Hapus</a></button>
      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>

<center><a class="text-dark" href="/xiirplb/tambah"> Tambah Siswa </a></center>

<br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agmar_XIIRPLB_ProjectKalender\resources\views/xiirplb.blade.php ENDPATH**/ ?>