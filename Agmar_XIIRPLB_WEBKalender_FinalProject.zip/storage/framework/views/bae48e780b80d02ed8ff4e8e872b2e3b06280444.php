<style>
        .container {
            font-family: 'Noto Sans', sans-serif;        }
        h3 {
            margin-bottom: 30px;
        }
        th {
            height: 20px;
            text-align: center;
        }
        td {
            height: 10px;
        }
        .today {
            background: orange;
        }
        th:nth-of-type(1), td:nth-of-type(1) {
            color: red;
        }
        th:nth-of-type(7), td:nth-of-type(7) {
            color: blue;
        }
</style>


<!-- judul halaman -->
<!-- <?php $__env->startSection('judul halaman', 'Halaman Home'); ?> -->

<!-- Isi Konten -->
<?php $__env->startSection('konten'); ?>

            <div class="content float-left">
                <div class="title m-b-md">
                    Welcome
                </div>
                <div>
                    <h4> Selamat Datang di Web Kalender XII RPL B </h4>
                </div>
                <div>
                    <span>AGMAR | XII RPL B</span>
                </div>
            </div>
            <div class="content float-right">
                 <h3><a href="?ym=<?php echo e($prev); ?>">&lt;</a> <?php echo e($html_title); ?> <a href="?ym=<?php echo e($next); ?>">&gt;</a></h3>
                    <table class="table table-bordered">
                        <tr>
                            <th>S</th>
                            <th>M</th>
                            <th>T</th>
                            <th>W</th>
                            <th>T</th>
                            <th>F</th>
                            <th>S</th>
                        </tr>
                          <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <?php 
                                echo $week;
                              ?>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
            <center><a class="text-dark" href="/calendar"> Tambah Acara? </a></center>
            <br><br>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_agmar\resources\views/home.blade.php ENDPATH**/ ?>